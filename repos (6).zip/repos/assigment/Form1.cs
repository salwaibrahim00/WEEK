﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics.Eventing.Reader;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Linq.Expressions;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace _5._1_assigment
{
    public partial class Form1 : Form
    {

        double[] nums = new double[3];

        string textfile = "HEALTHY.txt";// The name of the  text file here 
        double weightKg, heightM;
        int TextBox;
        public class Customer
        {
            private string fname;
            private string lname;
            public Customer(string fn, string ln)
            {
                if (fn.Length == 0)
                {
                    MessageBox.Show("invalid fname, nameser to Dana");
                    fname = "Dana";
                }
                else
                    fname = fn;
                if (ln.Length == 0)
                {
                    MessageBox.Show("invalid lname , name , name set to Sami");
                    lname = "Sami";
                }
                else
                    lname = ln;
            }
            public string Fname
            {
                get { return fname; }
                set { fname = value; }

            }
            public void display()
            {
                MessageBox.Show(" customer name =" + fname + "" + lname);
            }
        }


        public class BMICalculator
        {
            public double CalculateBMI(double height, double weight)

            {
                if (height == 0)
                {
                    MessageBox.Show("Invalid height; BMI cannot be calculated.");
                    return 0;
                }
                return weight / (height * height);
            }
            public string GetBMICategory(double bmi)
            {
                if (bmi < 18.5)
                    return "underweight";
                else if (bmi < 24.9)
                    return "normal weight";
                else if (bmi < 29.9)
                    return "overweight";
                else
                    return "obese";

            }
            public void DisplayBMIInfo(double height, double weight)
            {
                double bmi = CalculateBMI(height, weight);
                string category = GetBMICategory(bmi);
                MessageBox.Show($"BMI:{bmi:F2}\nCategory:{category}");
            }
        }
        public class ChildrenBMICalculator : BMICalculator
        {
            public double CalculateBMI(double height, double weight)
            {
                if (height <= 0 || weight <= 0)
                {

                    MessageBox.Show(" invalid height or weight; BMI  for children cannot be  calculated");
                    return 0;

                }
                return weight / (height * height);
            }
            public string GetBMICategoryForChild(double bmi)
            {
                if (bmi < 12)
                    return "underweight";
                else if (bmi >= 12 && bmi < 17)
                    return "normal weight";
                else if (bmi >= 17 && bmi < 20)
                    return "overweight";
                else
                    return "obese";
            }


            public void DisplayBMIInfoForChild(double height, double weight, int age, string gender)

            {
                double bmi = CalculateBMI(height, weight);
                string category = GetBMICategoryForChild(bmi);
                MessageBox.Show($"BMI:{bmi:F2}\nCategory:{category}\nAge:{age}\nGender: {gender}");
            }



        }

        int GetChildAge()
        {
            if (int.TryParse(textBox20.Text, out int age))
            {
                return age;
            }
            else
            {
                MessageBox.Show("please enter a valid age");
                return 0;
            }
        }
        string GetChildGender()
        {
            if (radioButton1.Checked)
            {
                return " male";

            }
            else if (radioButton2.Checked)
            {
                return " female";
            }
            MessageBox.Show("please select the childs gender.");
            return string.Empty;



        }




        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        // check if the input values textbox1 , textbox2 and textbox 3 with the sorted values
        {
            if (double.TryParse(textBox1.Text, out nums[0]) &&
    double.TryParse(textBox2.Text, out nums[1]) &&
    double.TryParse(textBox3.Text, out nums[2]))

            {
                // sort the inputs from the smallest to the biggest
                Array.Sort(nums);
                // calculate the sum of the sorted numbers 
                double sum = nums[0] + nums[1] + nums[2];
                // display sum in textbox4
                textBox4.Text = sum.ToString();
                textBox4.ForeColor = (sum > 200) ? Color.DarkViolet : SystemColors.ControlText;

                textBox1.Text = nums[0].ToString();
                textBox2.Text = nums[1].ToString();
                textBox3.Text = nums[2].ToString();
                {


                }
            }
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

            textBox1.BackColor = Color.Blue;// change the background color blue
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            textBox2.BackColor = Color.DarkGreen;// change the backgroung color to darkgreen
        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {
            textBox3.BackColor = Color.Orange;// change the backgroung color to orange

        }

        private void button2_Click(object sender, EventArgs e)
        {
            decimal[] nums = new decimal[4];
            decimal sum = 0;
            // check if the input values in textbox5 and textbox and textbox 7 and textbox 8 can be parsed as decimals 
            if (decimal.TryParse(textBox5.Text, out nums[0]) &&
              decimal.TryParse(textBox6.Text, out nums[1]) &&
               decimal.TryParse(textBox7.Text, out nums[2]) &&
                  decimal.TryParse(textBox8.Text, out nums[3]))
            {
                Array.Sort(nums);


                // calculate the sum of the inputs values 
                for (int i = 0; i < nums.Length; i++)
                {
                    sum += nums[i];

                }

                decimal average = sum / 4;



                textBox9.Text = average.ToString("F2");
                string filepath = "s ";
                using (StreamWriter writer = new StreamWriter(filepath))
                {
                    writer.WriteLine("Average : " + average.ToString("F2"));
                }

                foreach (Control x in this.Controls)

                    if (x is Label)
                    {
                        // set the background color of the label to darkred

                        x.BackColor = Color.DarkRed;
                        // set the text color (forecolor) of the label to khai
                        x.ForeColor = Color.Khaki;


                        {

                            {


                                {




                                }
                            }
                        }
                    }
            }
        }





        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {

            // convert pounds to kilograms and show the results in a messagebox five times
            if (double.TryParse(textBox11.Text, out double pounds))

                for (int i = 0; i <= 5; i++)// use < instead of<= to loop 5 times
                {
                    double kilograms = pounds * 0.45359237;
                    // Display the results in a messagebox with additional information
                    MessageBox.Show($"i={i}pounds= {pounds},kilograms={kilograms:F2}", "answer");

                }
        }

        private void button4_Click(object sender, EventArgs e)
        {


            if (double.TryParse(textBox12.Text, out double inches))

                for (int i = 0; i <= 5; i++)// use < instead of<= to loop 2 times
                {
                    double meters = inches * 0.0254;
                    // Display the results in a messagebox with additional information
                    MessageBox.Show($" Iteration :{i + 1} \nInches:{inches:F2}\nMeters:{meters:F2}", "Conversion Result");
                    if (meters > 100)
                    {
                        textBox12.BackColor = Color.AliceBlue;
                    }
                }
        }

        private void button5_Click(object sender, EventArgs e)

        {
            try
            {
                if (File.Exists(textfile))
                {
                    string fileContent = File.ReadAllText(textfile);
                    MessageBox.Show(fileContent, "file content");
                }


                else
                {

                    MessageBox.Show("File does not exist .", "File Read");

                }

            }
            catch (Exception ex)

            {
                MessageBox.Show("an error occured:" + ex.Message, "error");
            }
        }

        private void button6_Click(object sender, EventArgs e)
        {
            // Append text from textbox 13 to the end of the "HEALTHY.txt" file.

            try
            {
                File.AppendAllText(textfile, textBox13.Text + Environment.NewLine);
                MessageBox.Show("text appended to the file.", "file append");
            }
            catch (Exception ex)
            {
                MessageBox.Show("an error occured:" + ex.Message, "error");
            }
        }

        private void button7_Click(object sender, EventArgs e)
        {
            // Allow the user to select a text file , read its content and displayit im textbox1 and a message box 
            openFileDialog1 = new OpenFileDialog();// declare openFileDialog1 locally.
            openFileDialog1.Title = "choose a file for reading";
            openFileDialog1.InitialDirectory = Environment.CurrentDirectory;
            openFileDialog1.Filter = "txt files (*.txt)|*.txt|All files(*.*)|*.*";
            openFileDialog1.FilterIndex = 1;
            openFileDialog1.ShowDialog();
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                var filepath = openFileDialog1.FileName;

                using (StreamReader reader = new StreamReader(filepath))
                {
                    var filecontent = reader.ReadToEnd();
                    textBox13.Text = (filecontent);
                    //Display the files content in a message box
                    MessageBox.Show(filecontent, "file content");
                }
            }
        }

        private void tableLayoutPanel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button9_Click(object sender, EventArgs e)

        {
            string firstName = textBox10.Text;
            String lastName = textBox17.Text;
            Customer customer = new Customer(firstName, lastName);
            customer.display();
            double height, weight;
            if (double.TryParse(textBox14.Text, out height) && double.TryParse(textBox15.Text, out weight))

            {
                BMICalculator bMICalculator = new BMICalculator();
                bMICalculator.DisplayBMIInfo(height, weight);
            }

        }




        private void button8_Click(object sender, EventArgs e)
        {
            textBox14.Clear();
            textBox15.Clear();
            textBox16.Clear();
            textBox5.Clear();
            textBox6.Clear();
            textBox7.Clear();
            textBox8.Clear();
            textBox1.Clear();
            textBox2.Clear();
            textBox3.Clear();
            textBox11.Clear();
            textBox12.Clear();
        }

        private void label9_Click(object sender, EventArgs e)
        {

        }

        private void label12_Click(object sender, EventArgs e)
        {

        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (listBox1.SelectedIndex == 0)
                MessageBox.Show("yougurt100,Eggs78,Grained bread75, Avocado240");
            else if (listBox1.SelectedIndex == 1)
                MessageBox.Show("Tuna 203, Mini sweet Peppers35, Hummus130, Apples95 ");
            else
            {
                MessageBox.Show(" poultry296, salmon 824,potatoes164,brown rice216");
            }


        }

        private void button11_Click(object sender, EventArgs e)
        {
            string firstName = textBox10.Text;
            String lastname = textBox17.Text;
            Customer customer = new Customer(firstName, lastname);
            customer.display();

        }









        private void textBox13_TextChanged(object sender, EventArgs e)
        {

        }


        private void textBox18_TextChanged(object sender, EventArgs e)
        {

        }

        private void button12_Click_1(object sender, EventArgs e)
        {
            string firstName = textBox10.Text;
            string lastname = textBox17.Text;
            Customer customer = new Customer(firstName, lastname);
            customer.display();
            double height, weight;
            if (double.TryParse(textBox18.Text, out height) && double.TryParse(textBox19.Text, out weight))
            {
                ChildrenBMICalculator bmiCalclator = new ChildrenBMICalculator();
                int age = GetChildAge();

                string gender = GetChildGender();

                ChildrenBMICalculator bmiCalculator = new ChildrenBMICalculator();
                bmiCalculator.DisplayBMIInfoForChild(height, weight, age, gender);


            }



        }
    

    

        private void button10_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}     